export const siteConfig = {
  name: "Kenya Safari Explorer",
  legalName: "Kenya Safari Explorer Tours & Travel Ltd",
  url: "https://kenyasafariexplorer.com",
  tagline: "Best Kenya Safaris & Tours — Masai Mara, Amboseli & Coast",
  description:
    "Discover the best Kenya tours and safaris. Explore Masai Mara, Amboseli, Samburu, Tsavo and the Kenyan coast with expert local guides. Award-winning Kenya travel experiences, Big Five safaris, honeymoons and beach escapes — book today.",
  keywords: [
    "Kenya safaris",
    "Kenya tours",
    "Masai Mara safari",
    "African safari packages",
    "Big Five safari Kenya",
    "Amboseli National Park",
    "wildebeest migration",
    "Kenya honeymoon packages",
    "Diani beach",
    "Mount Kenya trekking",
  ],
  nav: {
    home: "Home",
    tours: "Tours",
    destinations: "Destinations",
    about: "About Us",
    contact: "Contact",
  },
};

export const fullUrl = (path: string) => `${siteConfig.url}${path}`;

import { siteConfig, fullUrl } from "./site";
import type { Tour, Destination, Testimonial } from "@/db/schema";

/** Organization JSON-LD */
export function organizationJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "TravelAgency",
    name: siteConfig.legalName,
    url: siteConfig.url,
    telephone: "+254 700 000 000",
    email: "bookings@kenyasafariexplorer.com",
    description: siteConfig.description,
    image: fullUrl("/images/hero-safari.jpg"),
    address: {
      "@type": "PostalAddress",
      streetAddress: "Nairobi CBD, Kimathi Street",
      addressLocality: "Nairobi",
      addressRegion: "Nairobi County",
      postalCode: "00100",
      addressCountry: "KE",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: "-1.2921",
      longitude: "36.8219",
    },
    areaServed: "Kenya",
    priceRange: "$$$",
    sameAs: [
      "https://facebook.com/kenyasafariexplorer",
      "https://instagram.com/kenyasafariexplorer",
      "https://twitter.com/kenyasafari_ex",
    ],
  };
}

/** Tour JSON-LD (Product schema for rich results) */
export function tourJsonLd(tour: Tour, destination?: Destination) {
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name: tour.title,
    image: fullUrl(tour.image),
    description: tour.summary,
    sku: `KT-${tour.id}`,
    brand: {
      "@type": "Brand",
      name: siteConfig.legalName,
    },
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: tour.rating,
      reviewCount: tour.reviews,
    },
    offers: {
      "@type": "Offer",
      url: fullUrl(`/tours/${tour.slug}`),
      priceCurrency: "USD",
      price: tour.price,
      availability: "https://schema.org/InStock",
      validFrom: new Date().toISOString().split("T")[0],
    },
    additionalProperty: {
      "@type": "PropertyValue",
      name: "Duration",
      value: `${tour.days} days / ${tour.nights} nights`,
    },
    ...(destination
      ? { contentLocation: { "@type": "Place", name: destination.name } }
      : {}),
  };
}

/** Tour aggregate JSON-LD */
export function tourAggregateJsonLd(tours: Tour[]) {
  const lowestPrice = Math.min(...tours.map((t) => t.price));
  const highestPrice = Math.max(...tours.map((t) => t.price));
  return {
    "@context": "https://schema.org",
    "@type": "OfferCatalog",
    name: `${siteConfig.name} Tour Packages`,
    description:
      "Browse our curated Kenya safari tours, from Masai Mara to the Kenyan coast.",
    itemListElement: tours.map((t) => ({
      "@type": "Offer",
      name: t.title,
      url: fullUrl(`/tours/${t.slug}`),
      priceCurrency: "USD",
      price: t.price,
      description: t.summary,
    })),
    hasOfferCatalog: [
      {
        "@type": "OfferCatalog",
        name: "Price range",
        itemListElement: [
          { "@type": "Offer", priceCurrency: "USD", price: `${lowestPrice}-${highestPrice}` },
        ],
      },
    ],
  };
}

/** Breadcrumb JSON-LD */
export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      item: fullUrl(item.path),
    })),
  };
}

import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

/** Tour destinations in Kenya */
export const destinations = pgTable("destinations", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  region: text("region").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  highlights: jsonb("highlights").$type<string[]>().notNull().default([]),
  bestTimeToVisit: text("best_time_to_visit").notNull(),
  image: text("image").notNull(),
  featured: boolean("featured").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Tour packages */
export const tours = pgTable("tours", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  destinationSlug: text("destination_slug").notNull(),
  days: integer("days").notNull(),
  nights: integer("nights").notNull(),
  groupSize: integer("group_size").notNull(),
  price: integer("price").notNull(),
  difficulty: text("difficulty").notNull(),
  summary: text("summary").notNull(),
  description: text("description").notNull(),
  itinerary: jsonb("itinerary").$type<{ day: number; title: string; description: string }[]>().notNull().default([]),
  inclusions: jsonb("inclusions").$type<string[]>().notNull().default([]),
  exclusions: jsonb("exclusions").$type<string[]>().notNull().default([]),
  image: text("image").notNull(),
  gallery: jsonb("gallery").$type<string[]>().notNull().default([]),
  bestSeason: text("best_season").notNull(),
  featured: boolean("featured").notNull().default(false),
  rating: text("rating").notNull().default("5.0"),
  reviews: integer("reviews").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Customer testimonials */
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country").notNull(),
  tour: text("tour").notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  image: text("image").notNull(),
});

/** Tour inquiries / bookings */
export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  tourSlug: text("tour_slug").notNull().default("general"),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  travelDate: text("travel_date").notNull(),
  travelers: integer("travelers").notNull(),
  budget: text("budget").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Destination = typeof destinations.$inferSelect;
export type Tour = typeof tours.$inferSelect;
export type Testimonial = typeof testimonials.$inferSelect;
export type Inquiry = typeof inquiries.$inferSelect;

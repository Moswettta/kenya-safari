import Link from "next/link";
import Image from "next/image";
import { Clock, Users, Star, MapPin } from "lucide-react";
import type { Tour } from "@/db/schema";

export default function TourCard({ tour }: { tour: Tour }) {
  return (
    <Link
      href={`/tours/${tour.slug}`}
      className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
    >
      <div className="relative h-52 overflow-hidden">
        <Image
          src={tour.image}
          alt={tour.title}
          fill
          sizes="(max-width: 768px) 100vw, 400px"
          className="object-cover transition duration-500 group-hover:scale-110"
        />
        <span className="absolute left-3 top-3 rounded-full bg-amber-500 px-3 py-1 text-xs font-bold text-teal-950">
          {tour.days} Days
        </span>
        <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-xs font-semibold text-white">
          <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
          {tour.rating} ({tour.reviews})
        </span>
      </div>

      <div className="p-5">
        <div className="mb-2 flex items-center gap-1 text-xs font-medium uppercase tracking-wide text-teal-700">
          <MapPin className="h-3 w-3" />
          {tour.difficulty} · {tour.destinationSlug.replace(/-/g, " ")}
        </div>

        <h3 className="font-serif text-lg font-bold leading-snug text-slate-900 group-hover:text-teal-700">
          {tour.title}
        </h3>

        <p className="mt-2 line-clamp-2 text-sm text-slate-600">{tour.summary}</p>

        <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
          <div className="flex items-center gap-3 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" /> {tour.days}D/{tour.nights}N
            </span>
            <span className="flex items-center gap-1">
              <Users className="h-3.5 w-3.5" /> {tour.groupSize} max
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] uppercase text-slate-400">from</span>
            <div className="text-lg font-bold text-teal-700">
              ${tour.price.toLocaleString()}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

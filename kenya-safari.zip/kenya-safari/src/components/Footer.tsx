import Link from "next/link";
import { Phone, Mail, MapPin } from "lucide-react";
import { siteConfig } from "@/lib/site";

const socials = [
  {
    label: "Facebook",
    href: "https://facebook.com",
    d: "M22 12A10 10 0 1 0 12 22v-7h-2v-3h2V9.5C12 7.6 13.1 6.5 15 6.5c.9 0 1.8.2 1.8.2v2h-1.7c-1.2 0-1.5.7-1.5 1.5V12h3l-.5 3h-2.5v7A10 10 0 0 0 22 12z",
  },
  {
    label: "Instagram",
    href: "https://instagram.com",
    d: "M12 2c2.7 0 3 0 4.1.1 1.1.1 1.8.2 2.4.5.7.3 1.2.6 1.7 1.1.5.5.9 1 1.1 1.7.2.6.4 1.3.5 2.4.1 1.1.1 1.4.1 4.1s0 3-.1 4.1c-.1 1.1-.2 1.8-.5 2.4-.2.7-.6 1.2-1.1 1.7-.5.5-1 .9-1.7 1.1-.6.2-1.3.4-2.4.5-1.1.1-1.4.1-4.1.1s-3 0-4.1-.1c-1.1-.1-1.8-.2-2.4-.5-.7-.2-1.2-.6-1.7-1.1-.5-.5-.9-1-1.1-1.7-.2-.6-.4-1.3-.5-2.4C2 15 2 14.7 2 12s0-3 .1-4.1c.1-1.1.2-1.8.5-2.4.3-.7.6-1.2 1.1-1.7.5-.5 1-.9 1.7-1.1.6-.2 1.3-.4 2.4-.5C9 2 9.3 2 12 2zm0 4.5A5.5 5.5 0 1 0 17.5 12 5.5 5.5 0 0 0 12 6.5zm0 9A3.5 3.5 0 1 1 15.5 12 3.5 3.5 0 0 1 12 15.5zm5.6-9.4a1.3 1.3 0 1 0 1.3 1.3 1.3 1.3 0 0 0-1.3-1.3z",
  },
  {
    label: "X / Twitter",
    href: "https://twitter.com",
    d: "M18.9 2H22l-7.4 8.5L23 22h-6.8l-5.3-7-6.1 7H1.5l7.9-9L1 2h7l4.8 6.4L18.9 2zm-1.2 18h1.9L7 4H5l12.7 16z",
  },
  {
    label: "YouTube",
    href: "https://youtube.com",
    d: "M23 7.5s-.2-1.6-.9-2.3c-.9-1-1.9-1-2.4-1C16.6 4 12 4 12 4s-4.6 0-7.7.2c-.5.1-1.5.1-2.4 1-.7.7-.9 2.3-.9 2.3S1 9.4 1 11.3v1.4C1 14.6 1.2 16 1.2 16s.2 1.6.9 2.3c.9 1 2.1 1 2.6 1.1 1.9.2 7.3.2 7.3.2s4.6 0 7.7-.2c.5-.1 1.5-.1 2.4-1 .7-.7.9-2.3.9-2.3s.2-1.4.2-3.3v-1.4c0-1.9-.2-3.8-.2-3.8zM9.8 15.2V8.8l6.2 3.2-6.2 3.2z",
  },
];

export default function Footer() {
  const year = new Date().getFullYear();
  const tourLinks = [
    { name: "Great Kenya Safari", slug: "great-kenya-safari" },
    { name: "Amboseli & Kilimanjaro", slug: "amboseli-kilimanjaro-safari" },
    { name: "Kenya Coast & Beach", slug: "kenya-coast-safari-beach" },
    { name: "Samburu Special Five", slug: "samburu-special-five" },
    { name: "Big Five Classic", slug: "kenya-big-five-classic" },
    { name: "Honeymoon Escape", slug: "kenya-honeymoon-escape" },
  ];

  return (
    <footer className="bg-teal-950 text-teal-100">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-4">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <span className="text-2xl">🦁</span>
              <span className="font-serif text-lg font-bold text-white">
                Kenya Safari <span className="text-amber-400">Explorer</span>
              </span>
            </Link>
            <p className="mt-4 text-sm leading-relaxed text-teal-200">
              Award-winning local tour operator crafting authentic, unforgettable
              safaris across Kenya — from the Masai Mara to the Indian Ocean coast.
            </p>
            <div className="mt-5 flex gap-3">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-amber-500 hover:text-teal-950"
                >
                  <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4">
                    <path d={s.d} />
                  </svg>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-serif text-sm font-semibold uppercase tracking-wider text-amber-400">
              Pop‑up Tours
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              {tourLinks.map((t) => (
                <li key={t.slug}>
                  <Link
                    href={`/tours/${t.slug}`}
                    className="transition hover:text-amber-300"
                  >
                    {t.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-sm font-semibold uppercase tracking-wider text-amber-400">
              Company
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li><Link href="/about" className="hover:text-amber-300">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-amber-300">Contact & Booking</Link></li>
              <li><Link href="/tours" className="hover:text-amber-300">All Tours</Link></li>
              <li><Link href="/#destinations" className="hover:text-amber-300">Destinations</Link></li>
              <li><Link href="/terms" className="hover:text-amber-300">Terms & Conditions</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-sm font-semibold uppercase tracking-wider text-amber-400">
              Contact
            </h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 text-amber-400" />
                {siteConfig.legalName}, Kimathi Street, Nairobi CBD, Kenya
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-amber-400" />
                <a href="tel:+254700000000" className="hover:text-amber-300">+254 700 000 000</a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-amber-400" />
                <a href="mailto:bookings@kenyasafariexplorer.com" className="hover:text-amber-300">
                  bookings@kenyasafariexplorer.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6 text-center text-xs text-teal-300">
          <p>
            © {year} {siteConfig.legalName}. All rights reserved. Licensed Tour Operator — KATTA Reg. No. TR-000123.
          </p>
          <p className="mt-2">
            Explore Kenya responsibly: sustainable safaris, wildlife conservation & local community support.
          </p>
        </div>
      </div>
    </footer>
  );
}

"use client";

import { useState } from "react";
import { CheckCircle2 } from "lucide-react";

export default function InquiryForm({
  tourSlug,
  tourTitle,
}: {
  tourSlug: string;
  tourTitle?: string;
}) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    travelDate: "",
    travelers: 2,
    budget: "$2,000 - $3,000",
    message: "",
  });
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, tourSlug }),
      });
      if (!res.ok) throw new Error("Failed");
      setStatus("success");
    } catch {
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <div className="mt-5 rounded-xl bg-teal-50 p-5 text-center">
        <CheckCircle2 className="mx-auto h-10 w-10 text-teal-600" />
        <p className="mt-2 font-semibold text-teal-800">Request Received!</p>
        <p className="text-sm text-teal-700">
          Thank you for your interest in {tourTitle ?? "our safari"}. Our team
          will contact you within 24 hours with a tailored quote.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mt-5 space-y-3">
      <div>
        <label className="mb-1 block text-xs font-semibold text-slate-600">Full Name *</label>
        <input
          required
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Jane Doe"
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-200"
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-xs font-semibold text-slate-600">Email *</label>
          <input
            required
            type="email"
            name="email"
            value={form.email}
            onChange={handleChange}
            placeholder="you@email.com"
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-200"
          />
        </div>
        <div>
          <label className="mb-1 block text-xs font-semibold text-slate-600">Phone *</label>
          <input
            required
            name="phone"
            value={form.phone}
            onChange={handleChange}
            placeholder="+254 ..."
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-200"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-xs font-semibold text-slate-600">Travel Date</label>
          <input
            type="date"
            name="travelDate"
            value={form.travelDate}
            onChange={handleChange}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="mb-1 block text-xs font-semibold text-slate-600">Travelers</label>
          <input
            type="number"
            min="1"
            name="travelers"
            value={form.travelers}
            onChange={handleChange}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none"
          />
        </div>
      </div>
      <div>
        <label className="mb-1 block text-xs font-semibold text-slate-600">Budget / Person</label>
        <select
          name="budget"
          value={form.budget}
          onChange={handleChange}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none"
        >
          <option>Under $1,000</option>
          <option>$1,000 - $2,000</option>
          <option>$2,000 - $3,000</option>
          <option>$3,000 - $5,000</option>
          <option>Above $5,000</option>
        </select>
      </div>
      <div>
        <label className="mb-1 block text-xs font-semibold text-slate-600">Message</label>
        <textarea
          rows={3}
          name="message"
          value={form.message}
          onChange={handleChange}
          placeholder="Tell us about your dream safari..."
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none focus:ring-2 focus:ring-teal-200"
        />
      </div>
      {status === "error" && (
        <p className="text-sm text-rose-600">Something went wrong. Please try again.</p>
      )}
      <button
        type="submit"
        disabled={status === "loading"}
        className="w-full rounded-lg bg-teal-700 py-3 font-semibold text-white transition hover:bg-teal-800 disabled:opacity-60"
      >
        {status === "loading" ? "Sending..." : "Send Enquiry"}
      </button>
      <p className="text-center text-[11px] text-slate-400">
        No payment required — we&apos;ll respond within 24 hours.
      </p>
    </form>
  );
}

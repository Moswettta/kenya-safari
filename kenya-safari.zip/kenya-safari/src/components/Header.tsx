"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";

const navLinks = [
  { label: "Home", href: "/" },
  { label: "Tours", href: "/#tours" },
  { label: "Destinations", href: "/#destinations" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all ${
        scrolled || open
          ? "bg-teal-950/95 shadow-lg backdrop-blur"
          : "bg-gradient-to-b from-black/70 to-transparent"
      }`}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
            <span className="text-2xl">🦁</span>
            <span className="font-serif text-lg font-bold tracking-tight text-white sm:text-xl">
              Kenya Safari<span className="text-amber-400"> Explorer</span>
            </span>
          </Link>

          <div className="hidden items-center gap-1 md:flex">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="rounded-md px-3 py-2 text-sm font-medium text-white/90 transition hover:bg-white/10 hover:text-amber-300"
              >
                {link.label}
              </Link>
            ))}
            <a
              href="tel:+254700000000"
              className="ml-3 flex items-center gap-2 rounded-full bg-amber-500 px-4 py-2 text-sm font-semibold text-teal-950 transition hover:bg-amber-400"
            >
              <Phone className="h-4 w-4" />
              Book Now
            </a>
          </div>

          <button
            className="md:hidden text-white"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle menu"
          >
            {open ? <X className="h-7 w-7" /> : <Menu className="h-7 w-7" />}
          </button>
        </div>

        {open && (
          <div className="space-y-1 pb-4 md:hidden">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="block rounded-md px-3 py-2 text-base font-medium text-white/90 hover:bg-white/10"
              >
                {link.label}
              </Link>
            ))}
            <a
              href="tel:+254700000000"
              className="mt-2 flex items-center justify-center gap-2 rounded-full bg-amber-500 px-4 py-2 text-sm font-semibold text-teal-950"
            >
              <Phone className="h-4 w-4" /> +254 700 000 000
            </a>
          </div>
        )}
      </nav>
    </header>
  );
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { inquiries } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      tourSlug = "general",
      name,
      email,
      phone,
      travelDate,
      travelers,
      budget,
      message,
    } = body;

    if (!name || !email) {
      return NextResponse.json(
        { error: "Name and email are required" },
        { status: 400 }
      );
    }

    const result = await db
      .insert(inquiries)
      .values({
        tourSlug: String(tourSlug),
        name: String(name),
        email: String(email),
        phone: String(phone || ""),
        travelDate: String(travelDate || ""),
        travelers: Number(travelers || 1),
        budget: String(budget || ""),
        message: String(message || ""),
      })
      .returning({ id: inquiries.id });

    return NextResponse.json(
      { success: true, id: result[0]?.id },
      { status: 200 }
    );
  } catch (error) {
    console.error("Inquiry error:", error);
    return NextResponse.json(
      { error: "Unable to process request" },
      { status: 500 }
    );
  }
}

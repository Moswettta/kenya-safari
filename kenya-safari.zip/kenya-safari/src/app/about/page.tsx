import Image from "next/image";
import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { organizationJsonLd, breadcrumbJsonLd } from "@/lib/seo";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Kenya Safari Explorer is a locally owned, award-winning tour operator crafting authentic Kenya safaris. Meet the passionate team behind your dream African adventure.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <Header />
      <section className="relative flex h-[50vh] items-end">
        <Image
          src="/images/about-team.jpg"
          alt="Kenya Safari Explorer team leading travelers on a safari"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-10 sm:px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-wider text-amber-400">Our Story</p>
          <h1 className="mt-2 font-serif text-4xl font-bold text-white sm:text-5xl">
            About Kenya Safari Explorer
          </h1>
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <div className="space-y-5 leading-relaxed text-slate-700">
            <p>
              <strong className="text-slate-900">Kenya Safari Explorer</strong> was
              born from a simple love of our country and its extraordinary
              wildlife. Founded in Nairobi more than a decade ago, we are a
              proudly local tour operator dedicated to sharing Kenya&apos;s
              natural wonders with travelers from every corner of the globe.
            </p>
            <p>
              From the dramatic river crossings of the Great Migration to the
              gentle giants of Amboseli and the pristine sands of the Kenyan
              coast, our expert team has spent years perfecting journeys that
              are authentic, comfortable and truly unforgettable.
            </p>
            <p>
              Every safari we design supports local communities, cares for the
              environment, and ensures you travel with complete confidence and
              peace of mind. When you travel with us, you don&apos;t just see
              Kenya — you experience it.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="font-serif text-3xl font-bold text-slate-900">Our Core Values</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: "🤝", title: "Integrity", text: "Transparent pricing, honest advice and reliable service we stand behind." },
              { icon: "💚", title: "Conservation", text: "We partner with parks and communities to protect Kenya's wildlife for generations." },
              { icon: "✨", title: "Excellence", text: "Handpicked lodges, expert guides and flawless logistics on every journey." },
              { icon: "🧭", title: "Adventure", text: "Crafting authentic, off-the-beaten-path experiences that go beyond the ordinary." },
              { icon: "🌍", title: "Responsibility", text: "Sustainable travel that benefits local people and the environment." },
              { icon: "❤️", title: "Passion", text: "We truly love Kenya, and it shows in every detail of your safari." },
            ].map((v) => (
              <div key={v.title} className="rounded-2xl border border-slate-200 bg-white p-6">
                <div className="text-3xl">{v.icon}</div>
                <h3 className="mt-3 font-serif text-lg font-semibold text-slate-900">{v.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-teal-900 py-16 text-white">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
          <h2 className="font-serif text-3xl font-bold">Let&apos;s Plan Your Kenya Safari</h2>
          <p className="mt-4 text-teal-100">
            Speak with our friendly experts today and design a journey you&apos;ll
            treasure forever.
          </p>
          <a
            href="/contact"
            className="mt-6 inline-block rounded-full bg-amber-500 px-8 py-3 font-semibold text-teal-950 transition hover:bg-amber-400"
          >
            Get in Touch
          </a>
        </div>
      </section>

      <Footer />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd()) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "About", path: "/about" }])) }}
      />
    </>
  );
}

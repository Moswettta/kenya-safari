import Image from "next/image";
import type { Metadata } from "next";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import InquiryForm from "@/components/InquiryForm";
import { organizationJsonLd, breadcrumbJsonLd } from "@/lib/seo";

export const metadata: Metadata = {
  title: "Contact & Book Your Kenya Safari",
  description:
    "Contact Kenya Safari Explorer to plan your dream safari. Request a free quote, ask questions, or book a Kenya tour package online. We respond within 24 hours.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <>
      <Header />
      <section className="relative flex h-[45vh] items-end">
        <Image
          src="/images/diani-beach.jpg"
          alt="Contact Kenya Safari Explorer — Diani beach"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/55" />
        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-10 sm:px-6 lg:px-8">
          <h1 className="font-serif text-4xl font-bold text-white sm:text-5xl">
            Contact & Book Your Safari
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-white/90">
            Ready to explore Kenya? Tell us about your dream trip and our
            experts will craft the perfect itinerary — free consultation.
          </p>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-5">
            {/* Contact info */}
            <div className="space-y-6 lg:col-span-2">
              <h2 className="font-serif text-2xl font-bold text-slate-900">Get in Touch</h2>
              <p className="text-slate-600">
                Whether you have a question or want a tailored itinerary, we&apos;d
                love to hear from you.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4">
                  <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-teal-700" />
                  <div>
                    <p className="font-semibold text-slate-900">Visit Us</p>
                    <p className="text-sm text-slate-600">
                      Kenya Safari Explorer Tours & Travel Ltd,<br />
                      Kimathi Street, Nairobi CBD, Kenya
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4">
                  <Phone className="mt-0.5 h-5 w-5 shrink-0 text-teal-700" />
                  <div>
                    <p className="font-semibold text-slate-900">Call Us</p>
                    <p className="text-sm text-slate-600">
                      <a href="tel:+254700000000" className="hover:text-teal-700">+254 700 000 000</a>
                      <br />
                      <a href="tel:+254111000000" className="hover:text-teal-700">+254 111 000 000</a>
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4">
                  <Mail className="mt-0.5 h-5 w-5 shrink-0 text-teal-700" />
                  <div>
                    <p className="font-semibold text-slate-900">Email Us</p>
                    <p className="text-sm text-slate-600">
                      <a href="mailto:bookings@kenyasafariexplorer.com" className="hover:text-teal-700">
                        bookings@kenyasafariexplorer.com
                      </a>
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4">
                  <Clock className="mt-0.5 h-5 w-5 shrink-0 text-teal-700" />
                  <div>
                    <p className="font-semibold text-slate-900">Office Hours</p>
                    <p className="text-sm text-slate-600">Mon – Sat: 8:00 AM – 6:00 PM (EAT)</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="rounded-2xl border border-slate-200 bg-white p-7 shadow-sm lg:col-span-3">
              <h2 className="font-serif text-2xl font-bold text-slate-900">Send an Enquiry</h2>
              <p className="mt-1 text-sm text-slate-500">
                Fill in the form and our safari experts will get back to you within 24 hours.
              </p>
              <div className="mt-5 max-w-xl">
                <InquiryForm tourSlug="general" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd()) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "Contact", path: "/contact" }])) }}
      />
    </>
  );
}

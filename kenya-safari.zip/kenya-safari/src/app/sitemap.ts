import type { MetadataRoute } from "next";
import { db } from "@/db";
import { tours, destinations } from "@/db/schema";
import { siteConfig, fullUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = siteConfig.url;
  const currentDate = new Date();

  const [allTours, allDestinations] = await Promise.all([
    db.select().from(tours),
    db.select().from(destinations),
  ]);

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: baseUrl, lastModified: currentDate, changeFrequency: "weekly", priority: 1 },
    { url: fullUrl("/tours"), lastModified: currentDate, changeFrequency: "weekly", priority: 0.9 },
    { url: fullUrl("/destinations"), lastModified: currentDate, changeFrequency: "weekly", priority: 0.8 },
    { url: fullUrl("/about"), lastModified: currentDate, changeFrequency: "monthly", priority: 0.6 },
    { url: fullUrl("/contact"), lastModified: currentDate, changeFrequency: "monthly", priority: 0.7 },
    { url: fullUrl("/terms"), lastModified: currentDate, changeFrequency: "yearly", priority: 0.3 },
  ];

  const tourRoutes: MetadataRoute.Sitemap = allTours.map((t) => ({
    url: fullUrl(`/tours/${t.slug}`),
    lastModified: t.createdAt,
    changeFrequency: "weekly",
    priority: 0.8,
  }));

  const destinationRoutes: MetadataRoute.Sitemap = allDestinations.map((d) => ({
    url: fullUrl(`/destinations/${d.slug}`),
    lastModified: d.createdAt,
    changeFrequency: "weekly",
    priority: 0.8,
  }));

  return [...staticRoutes, ...tourRoutes, ...destinationRoutes];
}

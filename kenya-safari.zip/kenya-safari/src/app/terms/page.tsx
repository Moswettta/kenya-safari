import type { Metadata } from "next";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description:
    "Terms and conditions for booking a Kenya safari with Kenya Safari Explorer Tours & Travel Ltd.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <>
      <Header />
      <section className="bg-slate-50 px-4 pb-16 pt-28 sm:px-6">
        <div className="mx-auto max-w-3xl">
          <h1 className="font-serif text-4xl font-bold text-slate-900">Terms & Conditions</h1>
          <div className="mt-8 space-y-6 text-slate-700">
            <section>
              <h2 className="font-serif text-xl font-bold text-slate-900">Booking & Payment</h2>
              <p className="mt-2 leading-relaxed">
                A deposit of 30% is required to confirm any booking, with the balance
                due 60 days before departure. Payments can be made by bank transfer,
                card or secure payment link.
              </p>
            </section>
            <section>
              <h2 className="font-serif text-xl font-bold text-slate-900">Cancellation Policy</h2>
              <ul className="mt-2 list-disc space-y-1 pl-5">
                <li>More than 60 days: full refund minus admin fee</li>
                <li>30–60 days: 50% refund</li>
                <li>Less than 30 days: no refund (travel insurance advised)</li>
              </ul>
            </section>
            <section>
              <h2 className="font-serif text-xl font-bold text-slate-900">Travel Insurance</h2>
              <p className="mt-2 leading-relaxed">
                All travelers are strongly advised to obtain comprehensive travel
                insurance covering medical expenses, trip cancellation and personal
                effects.
              </p>
            </section>
            <section>
              <h2 className="font-serif text-xl font-bold text-slate-900">Responsibility</h2>
              <p className="mt-2 leading-relaxed">
                Kenya Safari Explorer acts as a tour operator and is not liable for
                events beyond our control including weather, flight delays, or force
                majeure. All arrangements are made in good faith on behalf of guests.
              </p>
            </section>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

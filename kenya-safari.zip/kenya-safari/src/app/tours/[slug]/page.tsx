import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { tours, destinations, inquiries } from "@/db/schema";
import { eq } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import InquiryForm from "@/components/InquiryForm";
import { breadcrumbJsonLd, tourJsonLd } from "@/lib/seo";

export const dynamic = "force-dynamic";

export default async function TourPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const tour = (
    await db.select().from(tours).where(eq(tours.slug, slug)).limit(1)
  )[0];

  if (!tour) notFound();

  const destination = (
    await db
      .select()
      .from(destinations)
      .where(eq(destinations.slug, tour.destinationSlug))
      .limit(1)
  )[0];

  const related = await db
    .select()
    .from(tours)
    .where(eq(tours.destinationSlug, tour.destinationSlug))
    .limit(3);

  return (
    <>
      <Header />

      {/* Hero */}
      <section className="relative flex h-[60vh] items-end">
        <Image
          src={tour.image}
          alt={tour.title}
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-10 sm:px-6 lg:px-8">
          <p className="text-sm font-medium uppercase tracking-wider text-amber-400">
            {destination?.name ?? tour.destinationSlug}
          </p>
          <h1 className="mt-2 max-w-3xl font-serif text-3xl font-bold text-white sm:text-5xl">
            {tour.title}
          </h1>
          <div className="mt-4 flex flex-wrap items-center gap-4 text-white/90">
            <span className="flex items-center gap-1">★ {tour.rating} ({tour.reviews} reviews)</span>
            <span>·</span>
            <span>{tour.days} Days / {tour.nights} Nights</span>
            <span>·</span>
            <span>Up to {tour.groupSize} travelers</span>
            <span>·</span>
            <span>{tour.difficulty}</span>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-3">
            {/* Main content */}
            <div className="space-y-10 lg:col-span-2">
              {/* Summary */}
              <div className="rounded-2xl border border-slate-200 bg-white p-7">
                <h2 className="font-serif text-2xl font-bold text-slate-900">Overview</h2>
                <p className="mt-3 leading-relaxed text-slate-700">{tour.description}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  <span className="rounded-full bg-teal-50 px-3 py-1 text-sm font-medium text-teal-700">
                    Best season: {tour.bestSeason}
                  </span>
                </div>
              </div>

              {/* Itinerary */}
              <div className="rounded-2xl border border-slate-200 bg-white p-7">
                <h2 className="font-serif text-2xl font-bold text-slate-900">
                  Itinerary ({tour.days} Days)
                </h2>
                <ol className="mt-5 space-y-5">
                  {tour.itinerary.map((item) => (
                    <li key={item.day} className="relative pl-10">
                      <span className="absolute left-0 top-1 flex h-7 w-7 items-center justify-center rounded-full bg-amber-500 text-xs font-bold text-teal-950">
                        D{item.day}
                      </span>
                      <h3 className="font-semibold text-slate-900">{item.title}</h3>
                      <p className="mt-1 text-sm leading-relaxed text-slate-600">{item.description}</p>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Inclusions / Exclusions */}
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="rounded-2xl border border-slate-200 bg-white p-7">
                  <h2 className="font-serif text-lg font-bold text-slate-900">What&apos;s Included</h2>
                  <ul className="mt-4 space-y-2 text-sm text-slate-700">
                    {tour.inclusions.map((inc) => (
                      <li key={inc} className="flex items-start gap-2">
                        <span className="text-teal-600">✔</span> {inc}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-white p-7">
                  <h2 className="font-serif text-lg font-bold text-slate-900">Not Included</h2>
                  <ul className="mt-4 space-y-2 text-sm text-slate-700">
                    {tour.exclusions.map((exc) => (
                      <li key={exc} className="flex items-start gap-2">
                        <span className="text-rose-500">✖</span> {exc}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Related tours */}
              {related.length > 0 && (
                <div>
                  <h2 className="font-serif text-2xl font-bold text-slate-900">
                    Alternative {destination?.name} Tours
                  </h2>
                  <div className="mt-5 space-y-3">
                    {related
                      .filter((r) => r.slug !== tour.slug)
                      .map((r) => (
                        <Link
                          key={r.id}
                          href={`/tours/${r.slug}`}
                          className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-3 transition hover:border-teal-400 hover:shadow"
                        >
                          <div className="relative h-16 w-24 shrink-0 overflow-hidden rounded-lg">
                            <Image src={r.image} alt={r.title} fill className="object-cover" />
                          </div>
                          <div className="flex-1">
                            <div className="font-semibold text-slate-900">{r.title}</div>
                            <div className="text-sm text-slate-500">{r.days} days</div>
                          </div>
                          <div className="font-bold text-teal-700">${r.price.toLocaleString()}</div>
                        </Link>
                      ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar / booking */}
            <aside className="lg:col-span-1">
              <div className="sticky top-20 space-y-5">
                <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-xs uppercase text-slate-400">per person</p>
                      <p className="text-3xl font-bold text-teal-700">${tour.price.toLocaleString()}</p>
                    </div>
                    <div className="text-xs text-slate-500">★ {tour.rating} ({tour.reviews})</div>
                  </div>
                  <InquiryForm tourSlug={tour.slug} tourTitle={tour.title} />
                </div>

                <div className="rounded-2xl border border-slate-200 bg-teal-50 p-6">
                  <h3 className="font-serif font-bold text-slate-900">Why book with us?</h3>
                  <ul className="mt-3 space-y-2 text-sm text-slate-700">
                    <li>✔ Local Kenyan experts</li>
                    <li>✔ Best price guarantee</li>
                    <li>✔ Flexible rescheduling</li>
                    <li>✔ 100% safe & secure booking</li>
                    <li>✔ Free consultation call</li>
                  </ul>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </section>

      <Footer />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(tourJsonLd(tour, destination)) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "Tours", path: "/tours" }, { name: tour.title, path: `/tours/${tour.slug}` }])) }}
      />
    </>
  );
}

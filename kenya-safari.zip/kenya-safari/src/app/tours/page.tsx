import Image from "next/image";
import type { Metadata } from "next";
import { db } from "@/db";
import { tours } from "@/db/schema";
import { desc } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TourCard from "@/components/TourCard";
import { breadcrumbJsonLd, tourAggregateJsonLd } from "@/lib/seo";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Kenya Safari Tours & Packages",
  description:
    "Browse the best Kenya safari tours: Masai Mara, Amboseli, Samburu, Tsavo, Mount Kenya and beach escapes. Award-winning packages, Big Five guaranteed, best prices.",
  alternates: { canonical: "/tours" },
  openGraph: {
    title: "Kenya Safari Tours & Packages",
    description:
      "Browse the best Kenya safari tours: Masai Mara, Amboseli, Samburu, Tsavo and beach escapes.",
  },
};

export default async function ToursPage() {
  const allTours = await db
    .select()
    .from(tours)
    .orderBy(desc(tours.featured));

  return (
    <>
      <Header />

      {/* hero */}
      <section className="relative flex h-[45vh] items-center justify-center">
        <Image
          src="/images/maasai-mara.jpg"
          alt="Kenya safari tours — Masai Mara wildebeest migration"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/55" />
        <div className="relative z-10 px-4 text-center text-white">
          <h1 className="font-serif text-4xl font-bold sm:text-5xl">Kenya Safari Tours</h1>
          <p className="mx-auto mt-4 max-w-2xl text-white/90">
            Explore our handpicked collection of the best Kenya safaris — from
            epic Big Five adventures to romantic coast escapes.
          </p>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {allTours.map((tour) => (
              <TourCard key={tour.id} tour={tour} />
            ))}
          </div>
        </div>
      </section>

      {/* SEO text */}
      <section className="bg-white py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <h2 className="font-serif text-2xl font-bold text-slate-900">
            The Best Kenya Safari Tours & Travel Packages
          </h2>
          <div className="mt-4 space-y-3 text-slate-600">
            <p>
              Whether you&apos;re seeking the excitement of the Great Wildebeest
              Migration, the iconic elephants of Amboseli, the rare species of
              Samburu, or the tropical paradise of Diani Beach, our Kenya safari
              tours cater to every traveler. Each package is crafted by local
              experts and includes comfortable 4x4 game drives, handpicked
              lodges, and unforgettable wildlife encounters.
            </p>
            <p>
              All tours can be fully customized to your dates, interests and
              budget. Contact our team to design your dream Kenya holiday today.
            </p>
          </div>
        </div>
      </section>

      <Footer />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(tourAggregateJsonLd(allTours)) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "Tours", path: "/tours" }])) }}
      />
    </>
  );
}

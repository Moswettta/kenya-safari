import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function NotFound() {
  return (
    <>
      <Header />
      <section className="flex min-h-[70vh] flex-col items-center justify-center bg-slate-50 px-4 text-center">
        <p className="text-7xl">🦒</p>
        <h1 className="mt-6 font-serif text-4xl font-bold text-slate-900">
          Page Not Found
        </h1>
        <p className="mt-3 max-w-md text-slate-600">
          The page you&apos;re looking for has wandered off the savannah. Let&apos;s
          get you back on safari.
        </p>
        <Link
          href="/"
          className="mt-6 rounded-full bg-teal-700 px-8 py-3 font-semibold text-white transition hover:bg-teal-800"
        >
          Back to Home
        </Link>
      </section>
      <Footer />
    </>
  );
}

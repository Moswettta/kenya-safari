import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { db } from "@/db";
import { destinations, tours } from "@/db/schema";
import { desc } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { breadcrumbJsonLd, organizationJsonLd } from "@/lib/seo";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Kenya Safari Destinations",
  description:
    "Explore Kenya's top safari destinations: Masai Mara, Amboseli, Samburu, Tsavo, Lake Nakuru, Diani Beach and Nairobi. Best time to visit, highlights and more.",
  alternates: { canonical: "/destinations" },
};

export default async function DestinationsPage() {
  const allDestinations = await db
    .select()
    .from(destinations)
    .orderBy(desc(destinations.featured));
  const allTours = await db.select().from(tours);

  return (
    <>
      <Header />
      <section className="relative flex h-[45vh] items-center justify-center">
        <Image
          src="/images/amboseli.jpg"
          alt="Kenya safari destinations — Amboseli elephants with Kilimanjaro"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/55" />
        <div className="relative z-10 px-4 text-center text-white">
          <h1 className="font-serif text-4xl font-bold sm:text-5xl">Kenya Safari Destinations</h1>
          <p className="mx-auto mt-4 max-w-2xl text-white/90">
            From iconic national parks to tropical beaches, discover the
            must-visit destinations across Kenya.
          </p>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            {allDestinations.map((d, idx) => {
              const tourCount = allTours.filter((t) => t.destinationSlug === d.slug).length;
              return (
                <article
                  key={d.id}
                  className={`flex flex-col items-center gap-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm lg:flex-row ${
                    idx % 2 === 1 ? "lg:flex-row-reverse" : ""
                  }`}
                >
                  <div className="relative h-72 w-full overflow-hidden rounded-2xl lg:w-1/2">
                    <Image
                      src={d.image}
                      alt={`${d.name} Kenya`}
                      fill
                      sizes="(max-width: 1024px) 100vw, 50vw"
                      className="object-cover"
                    />
                    <span className="absolute left-3 top-3 rounded-full bg-amber-500 px-3 py-1 text-xs font-bold text-teal-950">
                      {tourCount} Tours
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-semibold uppercase tracking-wider text-teal-600">
                      {d.region}
                    </p>
                    <h2 className="mt-1 font-serif text-2xl font-bold text-slate-900 lg:text-3xl">
                      {d.name}
                    </h2>
                    <p className="mt-1 text-sm font-medium text-amber-600">{d.tagline}</p>
                    <p className="mt-3 leading-relaxed text-slate-600">{d.description}</p>
                    <p className="mt-3 text-sm">
                      <span className="font-semibold text-slate-800">Best time to visit:</span>{" "}
                      <span className="text-teal-700">{d.bestTimeToVisit}</span>
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {d.highlights.slice(0, 4).map((h) => (
                        <span
                          key={h}
                          className="rounded-full bg-teal-50 px-3 py-1 text-xs font-medium text-teal-700"
                        >
                          {h}
                        </span>
                      ))}
                    </div>
                    <Link
                      href={`/destinations/${d.slug}`}
                      className="mt-5 inline-flex items-center gap-2 rounded-full bg-teal-700 px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-teal-800"
                    >
                      Explore {d.name.split(" ")[0]} →
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <Footer />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd()) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "Destinations", path: "/destinations" }])) }}
      />
    </>
  );
}

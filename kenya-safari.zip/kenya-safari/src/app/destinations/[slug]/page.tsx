import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { destinations, tours } from "@/db/schema";
import { eq } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TourCard from "@/components/TourCard";
import { breadcrumbJsonLd } from "@/lib/seo";

export const dynamic = "force-dynamic";

export default async function DestinationPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const destination = (
    await db.select().from(destinations).where(eq(destinations.slug, slug)).limit(1)
  )[0];

  if (!destination) notFound();

  const locationTours = await db
    .select()
    .from(tours)
    .where(eq(tours.destinationSlug, destination.slug));

  return (
    <>
      <Header />

      <section className="relative flex h-[55vh] items-end">
        <Image
          src={destination.image}
          alt={`${destination.name} Kenya`}
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-10 sm:px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-wider text-amber-400">
            {destination.region}
          </p>
          <h1 className="mt-2 max-w-3xl font-serif text-3xl font-bold text-white sm:text-5xl">
            {destination.name}
          </h1>
          <p className="mt-2 text-lg text-amber-300">{destination.tagline}</p>
        </div>
      </section>

      <section className="bg-slate-50 py-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-3">
            <div className="space-y-8 lg:col-span-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-7">
                <h2 className="font-serif text-2xl font-bold text-slate-900">
                  About {destination.name}
                </h2>
                <p className="mt-3 leading-relaxed text-slate-700">{destination.description}</p>
                <p className="mt-4 text-sm">
                  <span className="font-semibold text-slate-800">Best time to visit:</span>{" "}
                  <span className="text-teal-700">{destination.bestTimeToVisit}</span>
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-7">
                <h2 className="font-serif text-xl font-bold text-slate-900">Top Highlights</h2>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                  {destination.highlights.map((h) => (
                    <li key={h} className="flex items-start gap-2 text-slate-700">
                      <span className="text-amber-500">★</span> {h}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <aside>
              <div className="sticky top-20 rounded-2xl border border-slate-200 bg-teal-900 p-6 text-white">
                <h3 className="font-serif text-lg font-bold">
                  {locationTours.length} Tour{locationTours.length !== 1 ? "s" : ""} in {destination.name.split(" ")[0]}
                </h3>
                <p className="mt-2 text-sm text-teal-100">
                  Explore our curated safaris to this breathtaking destination.
                </p>
                <Link
                  href="#tours"
                  className="mt-4 inline-block rounded-full bg-amber-500 px-6 py-2.5 text-sm font-semibold text-teal-950 transition hover:bg-amber-400"
                >
                  View Tours
                </Link>
              </div>
            </aside>
          </div>

          <div id="tours" className="mt-14">
            <h2 className="font-serif text-2xl font-bold text-slate-900">
              Tours in {destination.name.split(" ").slice(0, 2).join(" ")}
            </h2>
            <div className="mt-7 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
              {locationTours.map((tour) => (
                <TourCard key={tour.id} tour={tour} />
              ))}
            </div>
          </div>
        </div>
      </section>

      <Footer />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify({ "@context": "https://schema.org", "@type": "Place", name: destination.name, description: destination.description, image: destination.image }) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "Destinations", path: "/destinations" }, { name: destination.name, path: `/destinations/${destination.slug}` }])) }}
      />
    </>
  );
}

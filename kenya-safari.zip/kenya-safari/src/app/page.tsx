import Image from "next/image";
import Link from "next/link";
import { db } from "@/db";
import { tours, destinations, testimonials } from "@/db/schema";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TourCard from "@/components/TourCard";
import {
  organizationJsonLd,
  tourAggregateJsonLd,
} from "@/lib/seo";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [allTours, allDestinations, allTestimonials] = await Promise.all([
    db.select().from(tours).orderBy(tours.featured),
    db.select().from(destinations).orderBy(destinations.featured),
    db.select().from(testimonials),
  ]);

  const featuredTours = allTours.filter((t) => t.featured).slice(0, 6);
  const featuredDestinations = allDestinations.filter((d) => d.featured);

  return (
    <>
      <Header />

      {/* HERO */}
      <section className="relative flex min-h-[90vh] items-center justify-center">
        <Image
          src="/images/hero-safari.jpg"
          alt="Masai Mara Kenya safari at sunset with elephants and zebras"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />

        <div className="relative z-10 mx-auto max-w-4xl px-4 text-center text-white">
          <p className="mb-4 inline-block rounded-full border border-amber-400/50 bg-black/40 px-4 py-1 text-sm font-medium text-amber-300">
            Award-Winning Kenya Safari Operator
          </p>
          <h1 className="text-4xl font-serif font-extrabold leading-tight drop-shadow-lg sm:text-6xl">
            Discover the Wild Heart of{" "}
            <span className="text-amber-400">Kenya</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-white/90 sm:text-xl">
            Authentic safaris across the Masai Mara, Amboseli, Samburu and the
            Kenyan coast. See the Big Five, the Great Migration and golden
            savannahs — curated by expert local guides.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="#tours"
              className="rounded-full bg-amber-500 px-8 py-3 text-base font-semibold text-teal-950 shadow-lg transition hover:bg-amber-400"
            >
              Browse Safari Tours
            </Link>
            <Link
              href="/contact"
              className="rounded-full border-2 border-white/70 bg-white/10 px-8 py-3 text-base font-semibold text-white backdrop-blur transition hover:bg-white hover:text-teal-900"
            >
              Plan My Safari
            </Link>
          </div>

          <div className="mt-12 grid grid-cols-2 gap-6 border-t border-white/20 pt-8 sm:grid-cols-4">
            {[
              { n: "12+", l: "Years of Experience" },
              { n: "8,500+", l: "Happy Travelers" },
              { n: "7", l: "Top Destinations" },
              { n: "4.9★", l: "Average Rating" },
            ].map((s) => (
              <div key={s.l} className="text-center">
                <div className="text-2xl font-bold text-amber-400 sm:text-3xl">{s.n}</div>
                <div className="mt-1 text-xs uppercase tracking-wide text-white/80 sm:text-sm">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* floating trust badges */}
        <div className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 gap-8 text-sm font-medium text-white/90 md:flex">
          <span className="flex items-center gap-2">🇰🇪 Locally Owned</span>
          <span className="flex items-center gap-2">🦁 Big Five Guaranteed</span>
          <span className="flex items-center gap-2">🛡 100% Safe Booking</span>
        </div>
      </section>

      {/* FEATURED TOURS */}
      <section id="tours" className="bg-slate-50 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-teal-600">Safari Tours</p>
            <h2 className="mt-2 font-serif text-3xl font-bold text-slate-900 sm:text-4xl">
              Our Most Popular Kenya Tours
            </h2>
            <p className="mt-4 text-slate-600">
              Handpicked safari packages to Kenya&apos;s most spectacular
              wilderness areas — every trip led by passionate local experts.
            </p>
          </div>

          <div className="mt-10 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {featuredTours.map((tour) => (
              <TourCard key={tour.id} tour={tour} />
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link
              href="/tours"
              className="inline-flex items-center gap-2 rounded-full border-2 border-teal-700 px-8 py-3 font-semibold text-teal-700 transition hover:bg-teal-700 hover:text-white"
            >
              View All Kenya Safaris →
            </Link>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="bg-teal-900 py-20 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-amber-400">Why Travel With Us</p>
            <h2 className="mt-2 font-serif text-3xl font-bold sm:text-4xl">
              The Kenya Safari Experience, Perfected
            </h2>
          </div>

          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: "🗺️",
                title: "Expert Local Guides",
                text: "Certified guides with deep knowledge of every park, species and Maasai culture — ensuring you see more and learn more.",
              },
              {
                icon: "🌍",
                title: "Private & Small Groups",
                text: "Travel your way with private 4x4s and small intimate groups. Flexible, personalised, never cookie-cutter.",
              },
              {
                icon: "💰",
                title: "Best Price Guarantee",
                text: "Transparent, competitive pricing with no hidden fees. Book directly with the operator and save up to 30%.",
              },
              {
                icon: "🏕️",
                title: "Handpicked Lodging",
                text: "Stay in carefully selected safari lodges, luxury tents and beach resorts that balance comfort and authenticity.",
              },
              {
                icon: "⚡",
                title: "24/7 On-Safari Support",
                text: "Our team is reachable around the clock during your trip for total peace of mind and instant problem-solving.",
              },
              {
                icon: "🌿",
                title: "Responsible Travel",
                text: "We support conservation, employ local communities, and practise low-impact, sustainable tourism.",
              },
            ].map((f) => (
              <div
                key={f.title}
                className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur transition hover:bg-white/10"
              >
                <div className="text-3xl">{f.icon}</div>
                <h3 className="mt-4 font-serif text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-teal-100">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DESTINATIONS */}
      <section id="destinations" className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-teal-600">Destinations</p>
            <h2 className="mt-2 font-serif text-3xl font-bold text-slate-900 sm:text-4xl">
              Explore Kenya&apos;s Iconic Destinations
            </h2>
            <p className="mt-4 text-slate-600">
              From the wildlife-rich plains of the Mara to the white sands of
              Diani — discover the places that make Kenya unforgettable.
            </p>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {featuredDestinations.map((d) => (
              <Link
                key={d.id}
                href={`/destinations/${d.slug}`}
                className="group relative h-72 overflow-hidden rounded-2xl shadow-md"
              >
                <Image
                  src={d.image}
                  alt={`${d.name} Kenya safari`}
                  fill
                  sizes="(max-width: 768px) 100vw, 400px"
                  className="object-cover transition duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <p className="text-xs font-medium uppercase tracking-wide text-amber-400">{d.region}</p>
                  <h3 className="font-serif text-xl font-bold text-white">{d.name}</h3>
                  <p className="mt-1 text-sm text-white/80">{d.tagline}</p>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Link
              href="/destinations"
              className="inline-flex items-center gap-2 rounded-full border-2 border-teal-700 px-8 py-3 font-semibold text-teal-700 transition hover:bg-teal-700 hover:text-white"
            >
              Discover All Destinations →
            </Link>
          </div>
        </div>
      </section>

      {/* CALL TO ACTION BANNER */}
      <section className="relative overflow-hidden bg-teal-950 py-20">
        <div className="absolute inset-0 bg-gradient-to-br from-teal-900 via-teal-800 to-amber-800 opacity-90" />
        <div className="relative z-10 mx-auto max-w-3xl px-4 text-center text-white">
          <h2 className="font-serif text-3xl font-bold sm:text-5xl">
            Ready for the Adventure of a Lifetime?
          </h2>
          <p className="mt-4 text-lg text-teal-100">
            Let&apos;s craft your perfect Kenya safari. Speak to our experts
            today for a tailor-made itinerary and exclusive pricing.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="/contact"
              className="rounded-full bg-amber-500 px-8 py-3 font-semibold text-teal-950 transition hover:bg-amber-400"
            >
              Get a Free Quote
            </Link>
            <a
              href="tel:+254700000000"
              className="rounded-full border-2 border-white/60 px-8 py-3 font-semibold text-white transition hover:bg-white hover:text-teal-900"
            >
              📞 +254 700 000 000
            </a>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-slate-50 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-wider text-teal-600">Testimonials</p>
            <h2 className="mt-2 font-serif text-3xl font-bold text-slate-900 sm:text-4xl">
              Loved by Travelers Worldwide
            </h2>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {allTestimonials.map((t) => (
              <figure
                key={t.id}
                className="flex flex-col rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
              >
                <div className="flex gap-1 text-amber-500">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>
                <blockquote className="mt-4 flex-1 text-slate-700">“{t.comment}”</blockquote>
                <figcaption className="mt-5 flex items-center gap-3 border-t border-slate-100 pt-4">
                  <Image
                    src={t.image}
                    alt={t.name}
                    width={44}
                    height={44}
                    className="rounded-full"
                  />
                  <div>
                    <div className="font-semibold text-slate-900">{t.name}</div>
                    <div className="text-xs text-slate-500">{t.country} · {t.tour}</div>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* BLOG / SEO TEXT BLOCK */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
          <p className="text-sm font-semibold uppercase tracking-wider text-teal-600">Plan Your Trip</p>
          <h2 className="mt-2 font-serif text-3xl font-bold text-slate-900 sm:text-4xl">
            Why Kenya is Africa&apos;s Ultimate Safari Destination
          </h2>
          <div className="mt-6 space-y-4 text-left text-slate-600">
            <p>
              Kenya is the birthplace of the safari and remains East Africa&apos;s
              finest wildlife destination. Home to more than 50 national parks
              and reserves, it offers an unrivalled concentration of iconic
              animals — from the Big Five to the great herds of the wildebeest
              migration. Whether you dream of floating over the Masai Mara in a
              hot-air balloon, watching elephants beneath Mount Kilimanjaro in
              Amboseli, or relaxing on the pristine beaches of Diani, Kenya
              delivers the trip of a lifetime.
            </p>
            <p>
              <strong className="text-slate-800">Best time to visit Kenya:</strong>{" "}
              The dry season (June–October) is ideal for wildlife viewing,
              especially the Great Migration. The coast shines from December to
              March. Whatever the season, our expert team designs the perfect
              itinerary for you.
            </p>
          </div>
        </div>
      </section>

      <Footer />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd()) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(tourAggregateJsonLd(allTours)) }}
      />
    </>
  );
}

import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Kenya Safari Explorer",
    short_name: "Kenya Safari",
    description:
      "Best Kenya safari tours and travel — Masai Mara, Amboseli, Samburu, Tsavo and the Kenyan coast.",
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#0f766e",
    icons: [
      {
        src: "/images/hero-safari.jpg",
        sizes: "512x512",
        type: "image/jpeg",
      },
    ],
  };
}
